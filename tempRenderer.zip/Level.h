#ifndef LEVEL_H
#define LEVEL_H
#include"ObjectImporter.h"
#include<string>

using namespace DirectX::SimpleMath;

class Level
{
public:

	std::vector<Geometry> objects;

private:

	ObjectImporter* objImporter;
	std::string fileName;
	int terrainIndex;

public:

	Level();
	~Level();

	//Get
	int getTerrainIndex(void) const;

	//Set



	bool initialize(ID3D11Device * in_device, ObjectImporter * importer);
	std::vector<Geometry>* getGeometry();
	int findObject(std::string name);

};

#endif // !LEVEL_H

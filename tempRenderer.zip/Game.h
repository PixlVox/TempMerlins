#ifndef GAME_H
#define GAME_H

#include"Engine.h"
#include"Level.h"
#include"ObjectImporter.h"
#include<DirectXMath.h>
#include<fstream>

class Game {

private:

	Camera cam;
	Engine engine;
	Level level;
	ObjectImporter objImporter;

	//Collision
	Collision collision;

	//Private
	void terrainCollision();
	void boxCollisions(float dt);

public:

	Game();
	~Game();

	void init(HINSTANCE* hInst, HWND* wHandle);
	void update(float dt);
	void writeToFile(void);

	//Get

	//Set


};

#endif // !GAME_H

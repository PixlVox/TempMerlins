const long WIN_WIDTH = 1600;
const long WIN_HEIGHT = 900;

using namespace DirectX::SimpleMath;
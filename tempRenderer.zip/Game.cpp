#include"Game.h"

Game::Game() {



}

Game::~Game() {



}

void Game::init(HINSTANCE* hInst, HWND* wHandle) {

	//Init Engine
	this->engine.init(wHandle);

	//init camera
	this->cam.initDI(hInst, wHandle);

	//Init level
	this->level.initialize(this->engine.getDevice(), &this->objImporter);
	
	//Create boundingBoxes
	std::string temp = "";
	for (int i = 0; i < this->level.getGeometry()->size(); i++) {

		temp = this->level.getGeometry()->at(i).getName();
		temp = temp.substr(0, 4);
		if (temp == "Wall") {
			
			this->level.getGeometry()->at(i).createBoundingBox();
			
		}

	}

	

	this->cam.createBoundingBox();

}

void Game::writeToFile(void) {

	std::ofstream outFile;
	outFile.open("NameCheck.txt");

	std::string temp = "";
	for (int i = 0; i < this->level.getGeometry()->size(); i++) {

		temp = this->level.getGeometry()->at(i).getName();
		outFile << temp << "\n";
		temp = "";

	}

	outFile.close();

}

void Game::update(float dt) {

	//Read keyboard/mouse input
	this->cam.getInput();

	//Check camera collision on terrain
	this->terrainCollision();
	this->boxCollisions(dt);

	//Update camera
	this->cam.update(dt);

	//Update engine
	this->engine.update(&this->cam, this->level.getGeometry());

}

void Game::terrainCollision() {

	//Camera pos
	Vector3 camPos = this->cam.getPosition();
	camPos.y += 1500;
	DirectX::XMVECTOR ray = { camPos.x, -1000000.0f, camPos.z };
	ray = DirectX::XMVectorSubtract(ray, camPos);
	ray = DirectX::XMVector3Normalize(ray);

	//Terrain Values
	int terrainIndex = this->level.getTerrainIndex();
	std::vector<Geometry::Vertex> vertices = this->level.getGeometry()->at(terrainIndex).getVertices();
	std::vector<int> indices = this->level.getGeometry()->at(terrainIndex).getIndices();

	if (terrainIndex != -1) {

		DirectX::XMMATRIX terrainWorld = this->level.getGeometry()->at(terrainIndex).getWorld();
		int vertexCount = this->level.getGeometry()->at(terrainIndex).getVertexCount();
		int rowColCount = sqrt(this->level.getGeometry()->at(terrainIndex).getVertexCount());

		//Transform origin/ray into terrain local space
		ray = DirectX::XMVector3Transform(ray, DirectX::XMMatrixInverse(&DirectX::XMMatrixDeterminant(this->level.getGeometry()->at(terrainIndex).getWorld()),
		this->level.getGeometry()->at(terrainIndex).getWorld()));

		camPos = Vector3::Transform(camPos, DirectX::XMMatrixInverse(&DirectX::XMMatrixDeterminant(this->level.getGeometry()->at(terrainIndex).getWorld()),
			this->level.getGeometry()->at(terrainIndex).getWorld()));

		bool stopSearch = false;
		float dist = 0.0f;
		Vector3 yValue = Vector3(0.0f, 0.0f, 0.0f);

		for (int i = 0; i < indices.size() && !stopSearch; i += 3) {

			//Triangle information
			Vector3 v0 = vertices.at(indices.at(i)).pos;
			Vector3 v1 = vertices.at(indices.at(i + 1)).pos;
			Vector3 v2 = vertices.at(indices.at(i + 2)).pos;

			if (DirectX::TriangleTests::Intersects(camPos, {0, -1, 0}, v0, v1, v2, dist)) {

				//Get average height
				yValue = Vector3::Transform(v0, terrainWorld);
				yValue += Vector3::Transform(v1, terrainWorld);
				yValue += Vector3::Transform(v2, terrainWorld);
				yValue /= 3.0f;

				//Set offset
				this->cam.setHeightValue(yValue.y);

				stopSearch = true;

			}

		}

	}

}

void Game::boxCollisions(float dt) {

	bool collision = false;
	std::string temp = "";
	for (int i = 0; i < this->level.getGeometry()->size(); i++) {

		temp = this->level.getGeometry()->at(i).getName();
		temp = temp.substr(0, 4);
		if (temp == "Wall") {

			collision = this->collision.checkCollision(&this->cam.getBoundingBox()->getBoundingBox(),
				&this->level.getGeometry()->at(i).getBoundingBox()->getBoundingBox());

			if (collision) {
				
				this->cam.handleCollision(this->level.getGeometry()->at(i).getBoundingBox());

			}
			/*
			collision = this->collision.checkPreCollision(&this->cam.getBoundingBox()->getBoundingBox(),
				&this->level.getGeometry()->at(i).getBoundingBox()->getBoundingBox(), this->cam.getSpeed(),
				this->cam.getForward());

			if (collision) {

				this->cam.handlePreCollision(this->level.getGeometry()->at(i).getBoundingBox(), dt);

			}
			*/

		}

	}

}